"""
SPR 1.1 - Sistema de Precificação e Relatórios
"""

__version__ = '1.1.0'

from .main import SPRSystem, main

__all__ = ['SPRSystem', 'main', '__version__']

from .main import SPRSystem, main

__all__ = ['SPRSystem', 'main', '__version__'] 